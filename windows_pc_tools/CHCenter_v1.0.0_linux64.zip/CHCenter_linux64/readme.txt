1.Tested on Ubuntu x64 : 16.04/18.04.
2.32 bits, or version under 16.04 is unsupported.

#Open ternimal and run GUI
sudo ./CHCenter

#To run firmware updater
sudo ./CHFirmwareUpdater